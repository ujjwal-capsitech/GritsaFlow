import type { JSX } from "react";
import { Navigate } from "react-router-dom";
import type { Rootstate } from "../redux/store";
import { useSelector } from "react-redux";

const PrivateRoute = ({ children }: { children: JSX.Element }) => {
  const isLogin = useSelector((state: Rootstate) => state.auth.isLogin);
  return isLogin ? children : <Navigate to="/" replace />;
};

export default PrivateRoute;
