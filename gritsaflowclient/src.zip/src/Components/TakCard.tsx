import React, { useState, useEffect } from "react";
import { Card, Typography, Select, Row, Col, Progress } from "antd";
import ReactECharts from "echarts-for-react";

const { Title } = Typography;
const { Option } = Select;

// Dummy Data for Pie (Tasks distribution)
const pieData = [
    { name: "Backlog", value: 10, color: "#4C9AFF" },
    { name: "Need to Discuss", value: 5, color: "#A5B4FC" },
    { name: "ToDo", value: 8, color: "#60A5FA" },
    { name: "In Progress", value: 20, color: "#22D3EE" },
    { name: "Developed", value: 12, color: "#F472B6" },
    { name: "UAT", value: 6, color: "#E879F9" },
    { name: "Testing", value: 7, color: "#FBBF24" },
    { name: "Done", value: 40, color: "#34D399" },
];

// Dummy Data for Priority

const priorities = [
    { label: "High", value: 107, color: "#22c55e" },
    { label: "Medium", value: 395, color: "#3b82f6" },
    { label: "Low", value: 186, color: "#ef4444" },
];
const pieChartOptions = {
    tooltip: {
        trigger: 'item',
    },
    legend: {
        orient: 'vertical',
        left: 'right',
        top: 'ce',
        icon: 'circle',
        itemGap: 12,
        textStyle: {
            fontSize: 12,
        },
    },
    series: [
        {
            name: 'Tasks',
            type: 'pie',
            radius: ['40%', '70%'], // Donut shape
            center: ['40%', '50%'],
            
            avoidLabelOverlap: false,
            label: {
                show: false,
                position: 'center',
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: 12,
                    fontWeight: 'bold',
                },
            },
            labelLine: {
                show: false,
            },
            data: pieData.map(item => ({
                value: item.value,
                name: item.name,
                itemStyle: { color: item.color },
            })),
        },
    ],
};


const TaskReportCard: React.FC = () => {
    const [scale, setScale] = useState(1);

    // Optional: dynamically adjust scale on window resize
    useEffect(() => {
        const handleResize = () => {
            // Example: scale card based on window width, min 0.5 max 1
            const width = window.innerWidth;
            let newScale = 1;
            if (width < 600) newScale = 0.7;
            else if (width < 400) newScale = 0.5;
            setScale(newScale);
        };

        window.addEventListener("resize", handleResize);
        handleResize(); // initialize

        return () => window.removeEventListener("resize", handleResize);
    }, []);

    return (
        <div
            style={{
                transform: `scale(${scale})`,
                transformOrigin: "top left",
                width: `${100 / scale}%`, // Prevent container shrinking in layout
                transition: "transform 0.3s ease",
            }}
        >
            <Card style={{ borderRadius: "14px", padding: "10px" }}>
                {/* ... rest of your card content ... */}
                <Row justify="space-between" align="middle" style={{ marginBottom: "10px" }}>
                    <Title level={5} style={{ margin: 0 }}>
                        Task Report
                    </Title>
                    <a href="#">View all</a>
                </Row>

                <Row gutter={16}>
                    <Col xs={24} md={12} style={{ textAlign: "center" }}>
                        <ReactECharts
                            option={pieChartOptions}
                            style={{ height: "260px", width: "100%" }}
                        />
                    </Col>

                    <Col span={12}>
                        <Select
                            defaultValue="Sponsicore"
                            style={{ width: "100%", marginBottom: "15px" }}
                        >
                            <Option value="Sponsicore">Sponsicore</Option>
                            <Option value="Project A">Total Time Pay</Option>
                            <Option value="Project B">CapsiTask</Option>
                        </Select>

                        {priorities.map((p, idx) => (
                            <Row key={idx} align="middle" style={{ marginBottom: "12px" }}>
                                <Col span={6}>{p.label}</Col>
                                <Col span={12}>
                                    <Progress
                                        percent={Math.min((p.value / 400) * 100, 100)}
                                        showInfo={false}
                                        strokeColor={p.color}
                                        trailColor="#f3f4f6"
                                        status="active"
                                    />
                                </Col>
                                <Col span={6} style={{ textAlign: "right" }}>
                                    {p.value}
                                </Col>
                            </Row>
                        ))}
                    </Col>
                </Row>
            </Card>
        </div>
    );
};

export default TaskReportCard;
