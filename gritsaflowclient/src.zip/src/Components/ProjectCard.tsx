import React, { useEffect, useState } from "react";
import { Card, Typography, Select, Row, Col, Spin, message, Empty } from "antd";
import ReactECharts from "echarts-for-react";

import api from "../api/api";

const { Title } = Typography;
const { Option } = Select;

interface TaskReport {
    name: string;
    value: number;
}

interface Project {
    projectId: string;
    projectTitle: string;
}

interface ApiResponse<T> {
    success: boolean;
    data: T;
    message?: string;
}

const Projectcard: React.FC = () => {
    const [data, setData] = useState<TaskReport[]>([]);
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [selectedProject, setSelectedProject] = useState<string | null>(null);

    const fetchProjects = async () => {
        try {
            setLoading(true); //  start loading here too
            const response = await api.get<ApiResponse<Project[]>>("/ProjectControllers");

            console.log("Projects Response:", response.data); // debug log

            if (response.data.success) {
                setProjects(response.data.data);
                if (response.data.data.length > 0) {
                    setSelectedProject(response.data.data[0].projectId); // default select first project
                } else {
                    message.info("No projects found"); // nicer than error
                }
            } else {
                message.error(response.data.message || "Failed to load projects");
            }
        } catch (err) {
            message.error("Error fetching project list");
        } finally {
            setLoading(false); // end loading
        }
    };

    // Fetch project report
    const fetchReport = async (projectId: string) => {
        try {
            setLoading(true);
            const response = await api.get<ApiResponse<TaskReport[]>>(
                `/ProjectControllers/${projectId}/report`
            );

            console.log("Report Response:", response.data); // debug log

            if (response.data.success) {
                setData(response.data.data);
                if (response.data.data.length === 0) {
                    message.info("No report data available");
                }
            } else {
                message.error(response.data.message || "Failed to load report");
            }
        } catch {
            message.error("Error fetching report");
        } finally {
            setLoading(false); //  always stop loading
        }
    };


    // Load projects on mount
    useEffect(() => {
        fetchProjects();
    }, []);

    // Load report whenever selected project changes
    useEffect(() => {
        if (selectedProject) {
            fetchReport(selectedProject);
        }
    }, [selectedProject]);

    const pieChartOptions = {
        tooltip: { trigger: "item" },
        legend: {
            top: "center",
            left: "rigth",
            icon: "circle",
            orient: "vertical",
            itemGap: 12,
            textStyle: {
                fontSize:12
            }
        },
        series: [
            {
                name: "Tasks",
                type: "pie",
                radius: ["40%", "70%"],
                avoidLabelOverlap: true,
                label: { show: false, position: "center" },
                emphasis: { label: { show: true, fontSize: 12 } },
                labelLine: { show: false },
                data: data.map((item, index) => ({
                    value: item.value,
                    name: item.name,
                    itemStyle: {
                        color: [
                            "#4C9AFF",
                            "#A5B4FC",
                            "#60A5FA",
                            "#22D3EE",
                            "#F472B6",
                            "#E879F9",
                            "#FBBF24",
                            "#34D399",
                        ][index % 8],
                    },
                })),
            },
        ],
    };

    return (
        <Card style={{ borderRadius: "14px", padding: "10px" }}>
            <Row justify="space-between" align="middle" style={{ marginBottom: "10px" }}>
                <Title level={5} style={{ margin: 0 }}>
                    Project Report
                </Title>
                <a href="#">View all</a>
            </Row>

            <Row gutter={16}>
                {/* Left: Pie Chart */}
                <Col xs={24} md={ 12} style={{ textAlign: "center" }}>
                    {loading ? (
                        <Spin />
                    ) : data.length === 0 ? (
                        <Empty description="No Data" image={Empty.PRESENTED_IMAGE_SIMPLE} />
                    ) : (
                        <ReactECharts
                            option={pieChartOptions}
                            style={{ height: "220px", width: "100%" }}
                        />
                    )}
                </Col>


                {/* Right: Project Dropdown */}
                <Col span={12}>
                    <Select
                        value={selectedProject || undefined}
                        onChange={(value) => setSelectedProject(value)}
                        style={{ width: "100%", marginBottom: "15px" }}
                        placeholder="Select Project"
                    >
                        {projects.map((p) => (
                            <Option key={p.projectId} value={p.projectId}>
                                {p.projectTitle}
                            </Option>
                        ))}
                    </Select>
                </Col>
            </Row>
        </Card>
    );
};

export default Projectcard;
