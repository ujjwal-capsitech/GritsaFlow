
import React from "react";
import ProjectTimelineCard from "../../../Components/ActivityLog";



const Project: React.FC = () => {


    return (
        <ProjectTimelineCard/>
     
    );
};

export default Project;