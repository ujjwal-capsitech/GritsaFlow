import type React from "react";
import { Card, Row } from "antd";

const Employee: React.FC = () => {
    return (
        <Row>

        </Row>
      
    )
}
export default Employee;