import type React from "react";
import { Card } from "antd";
const Task: React.FC = () => {
    return (
        <Card>
           
        </Card>
    )
}
export default Task;