// redux/slices/AuthSlice.ts
import { createSlice,  type PayloadAction } from "@reduxjs/toolkit";

interface AuthState {
    isLogin: boolean;
}

const initialState: AuthState = {
    isLogin: localStorage.getItem("isLogin") === "true`"
};

const AuthSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        setIsLogin: (state, action: PayloadAction<boolean>) => {
            state.isLogin = action.payload;
        },
    },
});

export const { setIsLogin } = AuthSlice.actions;
export default AuthSlice.reducer;
